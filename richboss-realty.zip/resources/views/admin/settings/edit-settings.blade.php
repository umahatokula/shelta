@extends('layouts.app')

@section('content')
    <livewire:settings.edit-settings />
@endsection
