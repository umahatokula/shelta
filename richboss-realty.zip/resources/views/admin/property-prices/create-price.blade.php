@extends('layouts.app')

@section('content')
    <livewire:property-prices.create-price />
@endsection
