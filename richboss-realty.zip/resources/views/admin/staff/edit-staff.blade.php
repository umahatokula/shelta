@extends('layouts.app')

@section('content')
    <livewire:staff.edit-staff :staff="$staff" />
@endsection
