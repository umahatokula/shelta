@extends('layouts.app')

@section('content')
    <livewire:clients.create />
@endsection