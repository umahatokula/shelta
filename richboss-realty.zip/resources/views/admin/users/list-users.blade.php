@extends('layouts.app')

@section('content')
    <livewire:users.list-users />
@endsection