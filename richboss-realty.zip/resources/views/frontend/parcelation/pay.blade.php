@extends('layouts.frontend')

@section('content')
    <livewire:parcelation.pay :property="$property" />
@endsection