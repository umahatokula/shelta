@extends('layouts.frontend')

@section('content')
    <livewire:parcelation.select-plot />
@endsection