<?php

return [
    // Path to access migrator page
    'route' => 'migrator',

    // Middleware to authorize the admin user
    'middleware' => 'auth'
];
