<?php

return [

    'payment_reminder_days' => env('PAYMENT_REMINDER_DAYS', 3),

];
