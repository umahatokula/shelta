<?php

namespace App\Http\Livewire\Clients;

use Livewire\Component;

class Store extends Component
{
    public function render()
    {
        return view('livewire.clients.store');
    }
}
