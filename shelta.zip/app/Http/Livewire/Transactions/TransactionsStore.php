<?php

namespace App\Http\Livewire\Transactions;

use Livewire\Component;

class TransactionsStore extends Component
{
    public function render()
    {
        return view('livewire.transactions.transactions-store');
    }
}
