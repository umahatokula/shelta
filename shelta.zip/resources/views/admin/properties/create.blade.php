@extends('layouts.app')

@section('content')
    <livewire:properties.create-property />
@endsection