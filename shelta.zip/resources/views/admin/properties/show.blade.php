@extends('layouts.app')

@section('content')
    <livewire:properties.show :property="$property" />
@endsection