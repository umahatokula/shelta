@extends('layouts.app')

@section('content')
    <livewire:clients.edit :client="$client" />
@endsection