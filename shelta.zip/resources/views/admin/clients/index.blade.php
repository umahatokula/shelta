@extends('layouts.app')

@section('content')
    <livewire:clients.index />
@endsection