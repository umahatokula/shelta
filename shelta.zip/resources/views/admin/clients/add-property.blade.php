@extends('layouts.app')

@section('content')
    <livewire:clients.add-property :client="$client" />
@endsection