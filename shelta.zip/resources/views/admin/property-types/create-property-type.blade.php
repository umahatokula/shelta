@extends('layouts.app')

@section('content')
    <livewire:property-types.create-property-type />
@endsection
