@extends('layouts.app')

@section('content')
    <livewire:property-types.list-property-types />
@endsection
