@extends('layouts.app')

@section('content')
    <livewire:property-types.edit-property-type :propertyType="$propertyType"/>
@endsection
