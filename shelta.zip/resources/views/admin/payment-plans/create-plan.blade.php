@extends('layouts.app')

@section('content')
    <livewire:payment-plans.create-plan />
@endsection
