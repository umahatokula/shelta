@extends('layouts.app')

@section('content')
    <livewire:settings.payment-reminders />
@endsection
