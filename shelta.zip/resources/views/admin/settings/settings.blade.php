@extends('layouts.app')

@section('content')
    <livewire:settings.settings />
@endsection
