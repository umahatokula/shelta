@extends('layouts.app')

@section('content')
    <livewire:property-prices.prices />
@endsection
