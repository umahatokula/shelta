@extends('layouts.app')

@section('content')
    <livewire:property-prices.edit-price :propertyPrice="$propertyPrice" />
@endsection
