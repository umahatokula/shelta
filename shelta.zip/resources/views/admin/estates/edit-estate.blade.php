@extends('layouts.app')

@section('content')
    <livewire:estates.edit-estate :estate="$estate" />
@endsection
