@extends('layouts.app')

@section('content')
    <livewire:estates.create-estate />
@endsection
