@extends('layouts.app')

@section('content')
    <livewire:estates.list-estates />
@endsection
