@extends('layouts.app')

@section('content')
    <livewire:staff.list-staff />
@endsection
