@extends('layouts.app')

@section('content')
    <livewire:staff.profile :staff="$staff" />
@endsection
