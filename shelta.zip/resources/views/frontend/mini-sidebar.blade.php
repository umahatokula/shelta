<ul class="services-list">
    <li><a class="active" href="{{ route('frontend.clients.profile') }}">My Profile</a></li>
    <li><a class="" href="{{ route('frontend.password.change') }}">Change Password</a></li>
    <li><a href="{{ route('frontend.clients.security') }}">Security</a></li>
</ul>