@extends('layouts.frontend')

@section('content')

    <livewire:frontend.transactions.record :client="$client">

@endsection