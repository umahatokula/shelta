@extends('layouts.frontend')

@section('content')

    <livewire:frontend.transactions.online :client="$client">

@endsection