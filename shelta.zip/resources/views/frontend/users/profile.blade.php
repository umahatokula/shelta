@extends('layouts.frontend')
@section('content')

<div class="form-check form-switch">
    <input name="remember" class="form-check-input" type="checkbox" id="remember_me" checked="">
    <label class="form-check-label" for="remember_me">Remember me</label>
</div>

@endsection