@extends('layouts.frontend')

@section('content')

<!-- start page title -->
<div class="row">
    <div class="col-12">
        
    </div>
</div>
@endsection
