
<footer id="rs-footer" class="rs-footer style1">
    <div class="footer-bottom">
        <div class="container">                    
            <div class="row y-middle">
                <div class="col-lg-6">
                    <div class="copyright text-lg-start text-center ">
                        <p>© {{ date('Y').' '.env('APP_NAME') }}.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>