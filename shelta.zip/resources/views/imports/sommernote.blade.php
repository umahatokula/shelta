    <!-- Javascripts -->
    <script src="{{ asset('assets') }}/plugins/jquery/jquery-3.5.1.min.js"></script>
    <script src="{{ asset('assets') }}/plugins/bootstrap/js/popper.min.js"></script>
    <script src="{{ asset('assets') }}/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="{{ asset('assets') }}/plugins/perfectscroll/perfect-scrollbar.min.js"></script>
    <script src="{{ asset('assets') }}/plugins/pace/pace.min.js"></script>
    <script src="{{ asset('assets') }}/plugins/highlight/highlight.pack.js"></script>
    <script src="{{ asset('assets') }}/plugins/summernote/summernote-lite.min.js"></script>
    <script src="{{ asset('assets') }}/js/main.min.js"></script>
    <script src="{{ asset('assets') }}/js/custom.js"></script>
    <script src="{{ asset('assets') }}/js/pages/text-editor.js"></script>
