
@extends('emails.layout.emailLayout')

@section('content')

<p>{!! $content !!}</p>

@endsection