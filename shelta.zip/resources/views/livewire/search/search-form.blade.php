
<form wire:submit.prevent="search">
  <input wire:model="query" class="form-control" type="text" placeholder="Type here..." aria-label="Search">
</form>