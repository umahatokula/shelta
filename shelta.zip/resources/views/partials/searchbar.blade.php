<div class="search">
    
    <livewire:search.search-form />
    
    <a href="#" class="toggle-search"><i class="material-icons">close</i></a>
</div>

                          